import React from 'react';

const Settings: React.FC = () => (
  <div className="p-8">
    <h2 className="text-2xl font-bold mb-4">Settings</h2>
    <p>Theme switcher and other settings coming soon.</p>
  </div>
);
export default Settings;
